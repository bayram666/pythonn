import numpy as np

i2 = np.eye(2)
print(i2)
np.savetxt("eye.txt", i2)
