s = 'Hello world'
print(s)
