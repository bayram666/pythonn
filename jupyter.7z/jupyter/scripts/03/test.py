message = "Hello how are you?"
for word in message.split():
    print(word)